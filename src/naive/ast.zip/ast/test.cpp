#include "ast.h"

int main(){
    std::cout << 1 << std::endl;
}